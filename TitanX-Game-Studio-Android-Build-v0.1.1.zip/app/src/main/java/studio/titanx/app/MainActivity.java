package studio.titanx.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 40;
    private static final int SAVE_FILE = 41;
    private WebView editor;
    private android.webkit.ValueCallback<Uri[]> fileCallback;
    private byte[] pendingFile;

    private static final String DOWNLOAD_BRIDGE =
        "(function(){"+
        "if(window.__titanxSaveBridge)return;window.__titanxSaveBridge=true;"+
        "document.addEventListener('click',function(e){"+
        "var a=e.target.closest&&e.target.closest('a[download]');"+
        "if(!a||!a.href||a.href.indexOf('blob:')!==0)return;"+
        "e.preventDefault();e.stopPropagation();"+
        "fetch(a.href).then(function(r){return r.blob()}).then(function(blob){"+
        "var reader=new FileReader();reader.onload=function(){"+
        "var data=String(reader.result).split(',')[1];"+
        "AndroidBridge.saveFile(a.download||'titanx-export.html',blob.type||'text/html',data);"+
        "};reader.readAsDataURL(blob);"+
        "}).catch(function(){alert('Export failed')});"+
        "},true);"+
        "})();";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        editor = new WebView(this);
        WebSettings settings = editor.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        editor.addJavascriptInterface(new SaveBridge(), "AndroidBridge");
        editor.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(DOWNLOAD_BRIDGE, null);
            }
        });
        editor.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view,
                android.webkit.ValueCallback<Uri[]> callback,
                FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try { startActivityForResult(i, PICK_FILE); return true; }
                catch (Exception e) { fileCallback = null; return false; }
            }
        });
        setContentView(editor);
        editor.loadUrl("file:///android_asset/index.html");
    }

    private class SaveBridge {
        @JavascriptInterface public void saveFile(String filename, String mime, String base64) {
            try {
                pendingFile = Base64.decode(base64, Base64.DEFAULT);
                final String safeName = filename.replaceAll("[\\\\/:*?\"<>|]", "_");
                runOnUiThread(() -> {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                    i.putExtra(Intent.EXTRA_TITLE, safeName);
                    startActivityForResult(i, SAVE_FILE);
                });
            } catch (Exception e) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "Export failed", Toast.LENGTH_LONG).show()); }
        }
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == PICK_FILE && fileCallback != null) {
            Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
            fileCallback.onReceiveValue(uri == null ? null : new Uri[]{uri});
            fileCallback = null;
        } else if (req == SAVE_FILE && pendingFile != null) {
            if (result == RESULT_OK && data != null && data.getData() != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) { out.write(pendingFile); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show(); }
                } catch (Exception e) { Toast.makeText(this, "Save failed", Toast.LENGTH_LONG).show(); }
            }
            pendingFile = null;
        }
    }

    @Override public void onBackPressed() {
        if (editor != null && editor.canGoBack()) editor.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (editor != null) { editor.destroy(); editor = null; }
        super.onDestroy();
    }
}
