/* TitanX tiny 2D runtime - reusable in editor and self-contained HTML exports. */
function TitanXGameRuntime(canvas, project, options) {
  options = options || {};
  const ctx = canvas.getContext('2d', { alpha: false });
  const W = 896, H = 512, T = 32, COLS = 28, ROWS = 16;
  const colors = ['#376c53','#a37a4b','#3178a0','#6e7c91','#c9ab70','#765241'];
  let data = project, mode = options.mode || 'edit', playing = true, raf = 0;
  let lastTime = 0, accumulatedFPS = 0, frameCounter = 0, fps = 60;
  let t = 0, hero = {x:6.5*T, y:6.5*T}, coins = 0, enemies = {}, collected = {}, castAtTime = -5000;
  let keys = {}, pad = {x:0,y:0}, effects = [], rings = [], staticCache = null, cacheDirty = true;
  const quality = () => (data.quality || 'balanced');
  canvas.width = W; canvas.height = H;
  ctx.imageSmoothingEnabled = false;
  function hash(x,y,s) { let n = (x*374761393 + y*668265263 + s*127412617)|0; n = Math.imul(n ^ (n>>>13),1274126177); return (n ^ (n>>>16))>>>0; }
  function rnd(a,b) { return a + Math.random()*(b-a); }
  function tileAt(x,y) { let xx = Math.floor(x/T), yy = Math.floor(y/T); if (xx<0 || yy<0 || xx>=COLS || yy>=ROWS) return 2; return (data.tiles[yy] && data.tiles[yy][xx]) || 0; }
  function roundRect(x,y,w,h,r,fill) { ctx.beginPath();ctx.roundRect(x,y,w,h,r); ctx.fillStyle=fill;ctx.fill(); }
  function renderTile(x,y,id) {
    const X=x*T, Y=y*T, n=hash(x,y,6);
    ctx.fillStyle=colors[id] || colors[0];ctx.fillRect(X,Y,T,T);
    if (id===0) {
      ctx.fillStyle=n%3===0?'#447e5e':'#2f634c';
      for(let k=0;k<3;k++){let xx=X+((n >>> (k*5))%27)+2, yy=Y+((n >>> (k*7+1))%25)+3;ctx.fillRect(xx,yy,2,5);ctx.fillRect(xx+2,yy+2,2,2);}
    } else if(id===1) {ctx.fillStyle='#b68b59';ctx.fillRect(X+6,Y+8,7,2);ctx.fillRect(X+18,Y+23,5,2);}
    else if(id===2){ctx.fillStyle='#4392b4';ctx.fillRect(X+3,Y+7,13,2);ctx.fillRect(X+19,Y+24,10,2);ctx.fillStyle='#205e8b';ctx.fillRect(X+8,Y+16,14,2);}
    else if(id===3){ctx.fillStyle='#8593a6';ctx.fillRect(X+1,Y+2,20,2);ctx.fillRect(X+23,Y+18,8,2);ctx.fillStyle='#526071';ctx.fillRect(X+9,Y+21,14,2);}
    else if(id===4){ctx.fillStyle='#dac48e';ctx.fillRect(X+5,Y+6,7,3);ctx.fillRect(X+19,Y+21,10,2);}
    else if(id===5){ctx.fillStyle='#976e49';for(let z=6;z<32;z+=11)ctx.fillRect(X,Y+z,32,2);ctx.fillStyle='#60432f';ctx.fillRect(X+10,Y+3,2,3);}
  }
  function rebuildStatic(){
    staticCache=document.createElement('canvas');staticCache.width=W;staticCache.height=H;
    const old=ctx; // Renderer below uses the primary context: copy at once after drawing.
    for(let y=0;y<ROWS;y++) for(let x=0;x<COLS;x++) renderTile(x,y, data.tiles[y][x]);
    staticCache.getContext('2d').drawImage(canvas,0,0);cacheDirty=false;
  }
  function drawProp(obj){
    const X=(obj.x+0.5)*T,Y=(obj.y+0.9)*T,type=obj.type;
    if(type==='tree'){
      ctx.fillStyle='#172c2c66';ctx.beginPath();ctx.ellipse(X+9,Y+6,17,6,-.24,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#593e32';ctx.fillRect(X-5,Y-31,10,32);
      for(const [ox,oy,r,c] of [[-12,-48,17,'#244b42'],[11,-50,17,'#2a6251'],[0,-61,20,'#36785a'],[-6,-68,9,'#468e68']]){
        ctx.fillStyle=c;ctx.beginPath();ctx.arc(X+ox,Y+oy,r,0,Math.PI*2);ctx.fill();
      }
    } else if(type==='house'){
      ctx.fillStyle='#172c2c88';ctx.beginPath();ctx.ellipse(X+9,Y+7,37,10,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#d5ae72';ctx.fillRect(X-31,Y-48,62,53);
      ctx.fillStyle='#ad744f';ctx.fillRect(X-35,Y-60,70,14);ctx.fillStyle='#795447';
      ctx.beginPath();ctx.moveTo(X-41,Y-59);ctx.lineTo(X,Y-91);ctx.lineTo(X+41,Y-59);ctx.closePath();ctx.fill();
      ctx.fillStyle='#644736';ctx.fillRect(X-7,Y-24,15,29);ctx.fillStyle='#87bfd3';ctx.fillRect(X+15,Y-36,11,11);
    } else if(type==='rock'){
      ctx.fillStyle='#1b283b66';ctx.beginPath();ctx.ellipse(X+5,Y+4,21,6,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#738399';ctx.beginPath();ctx.moveTo(X-17,Y-3);ctx.lineTo(X-11,Y-20);ctx.lineTo(X+7,Y-25);ctx.lineTo(X+19,Y-8);ctx.lineTo(X+12,Y+4);ctx.closePath();ctx.fill();
      ctx.fillStyle='#a3b0bc';ctx.beginPath();ctx.moveTo(X-11,Y-20);ctx.lineTo(X+7,Y-25);ctx.lineTo(X+1,Y-7);ctx.lineTo(X-13,Y-6);ctx.closePath();ctx.fill();
    } else if(type==='bush'){
      ctx.fillStyle='#1b342b88';ctx.beginPath();ctx.ellipse(X,Y+3,16,5,0,0,Math.PI*2);ctx.fill();
      for(let k=0;k<3;k++){ctx.fillStyle=['#245c48','#2b7950','#38835b'][k];ctx.beginPath();ctx.arc(X-12+k*12,Y-11-(k%2)*5,11,0,Math.PI*2);ctx.fill();}
    } else if(type==='torch'){
      ctx.fillStyle='#19312baa';ctx.fillRect(X-10,Y,20,4);ctx.fillStyle='#7c5643';ctx.fillRect(X-3,Y-29,6,33);
      ctx.fillStyle='#ffbd57';ctx.beginPath();ctx.moveTo(X,Y-41);ctx.quadraticCurveTo(X+14,Y-26,X,Y-23);ctx.quadraticCurveTo(X-12,Y-32,X,Y-41);ctx.fill();
      ctx.fillStyle='#fff3b1';ctx.fillRect(X-2,Y-31,4,7);
    } else if(type==='chest') {
      if(collected[obj.id])return;
      ctx.fillStyle='#22293166';ctx.beginPath();ctx.ellipse(X,Y+3,15,5,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#795039';ctx.fillRect(X-15,Y-15,30,18);ctx.fillStyle='#bb8148';ctx.fillRect(X-15,Y-20,30,10);ctx.fillStyle='#e6be61';ctx.fillRect(X-3,Y-19,6,21);
    } else if(type==='npc') {
      ctx.fillStyle='#10291b66';ctx.beginPath();ctx.ellipse(X,Y+2,10,5,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#945bb5';ctx.fillRect(X-9,Y-25,18,25);ctx.fillStyle='#e1b48b';ctx.fillRect(X-6,Y-37,12,13);ctx.fillStyle='#513b39';ctx.fillRect(X-7,Y-41,14,6);
    } else if(type==='slime') {
      if(enemies[obj.id])return;
      let bob=Math.sin(t*3+obj.x)*2;
      ctx.fillStyle='#123b4677';ctx.beginPath();ctx.ellipse(X,Y+2,15,5,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#72d0a2';ctx.beginPath();ctx.ellipse(X,Y-10+bob,13,12,0,Math.PI,0);ctx.lineTo(X+13,Y);ctx.lineTo(X-13,Y);ctx.closePath();ctx.fill();
      ctx.fillStyle='#1d5260';ctx.fillRect(X-6,Y-10+bob,3,3);ctx.fillRect(X+4,Y-10+bob,3,3);
    } else if(type==='coin'){
      if(collected[obj.id])return;
      ctx.fillStyle='#f7d278';ctx.beginPath();ctx.ellipse(X,Y-11+Math.sin(t*4+obj.x)*3,8,10,0,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#a56c26';ctx.fillRect(X-1,Y-17+Math.sin(t*4+obj.x)*3,3,11);
    }
  }
  function drawHero(x,y) {
    ctx.fillStyle='#152e3577';ctx.beginPath();ctx.ellipse(x+7,y+2,15,5,0,0,Math.PI*2);ctx.fill();
    const pix = data.sprite || [];
    for(let i=0;i<256;i++){let c=pix[i];if(c){ctx.fillStyle=c;ctx.fillRect(Math.floor(x-16)+(i%16)*2,Math.floor(y-32)+Math.floor(i/16)*2,2,2);}}
  }
  function glow(x,y,r,color,alpha){
    const g=ctx.createRadialGradient(x,y,0,x,y,r);g.addColorStop(0,color);g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=alpha;ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);ctx.restore();
  }
  function burst(x,y) {
    const f=data.fx || {};
    let base = Math.max(5, Math.min(160,Number(f.count)||40));
    if(quality()==='low')base=Math.round(base*.42);
    if(fps<28)base=Math.round(base*.5);
    if(quality()==='high')base=Math.min(160,Math.round(base*1.25));
    const angleDir= f.kind==='rain' ? -Math.PI/2 : 0;
    let col=f.color || '#71e6ff';
    for(let i=0;i<base;i++){
      let a=rnd(0,Math.PI*2), speed = rnd(.28,1.15)*(Number(f.speed)||150);
      if(f.kind==='rain'){a=angleDir+rnd(-.35,.35);speed*=1.4;}
      const life=rnd(.4,1.1)*(Number(f.life)||.8);
      effects.push({x,y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,life,maxLife:life,size:rnd(1.5,Number(f.size)||5), color:col, gravity:f.kind==='flame'?-85:f.kind==='rain'?115:22});
    }
    rings.push({x,y,time:0,life:.62,color:col,kind:f.kind||'nova'});
    if(effects.length>280)effects.splice(0,effects.length-280);
  }
  function cast(x,y) {
    const now=performance.now();if(now-castAtTime<350)return false;
    castAtTime=now;burst(x,y);
    if(mode==='play'){
      for(const obj of data.objects){const ox=(obj.x+.5)*T, oy=(obj.y+.5)*T;
        if(obj.type==='slime' && !enemies[obj.id] && Math.hypot(x-ox,y-oy)<T*3.3){enemies[obj.id]=true;coins+=5; if(options.onMessage)options.onMessage('สลายสไลม์ +5 แต้ม');}}
      if(options.onHud)options.onHud(coins);
    }
    return true;
  }
  function collides(x,y) {
    const r=9;
    for(const [xx,yy] of [[x-r,y-r],[x+r,y-r],[x-r,y+r],[x+r,y+r]]){if(tileAt(xx,yy)===2)return true;}
    for(const p of data.objects){if(p.type==='house'||p.type==='tree'||p.type==='rock'){
      const px=(p.x+.5)*T,py=(p.y+.5)*T;
      if(Math.abs(x-px)<(p.type==='house'?27:10) && Math.abs(y-py)<(p.type==='house'?20:10))return true;
    }}return false;
  }
  function movement(dt){
    let dx=pad.x+(keys.ArrowRight||keys.d?1:0)-(keys.ArrowLeft||keys.a?1:0);
    let dy=pad.y+(keys.ArrowDown||keys.s?1:0)-(keys.ArrowUp||keys.w?1:0);
    let norm=Math.hypot(dx,dy);if(norm>0){dx/=norm;dy/=norm;const v=125*dt;const nx=hero.x+dx*v,ny=hero.y+dy*v;
      if(!collides(nx,hero.y))hero.x=Math.min(W-12,Math.max(12,nx));
      if(!collides(hero.x,ny))hero.y=Math.min(H-12,Math.max(12,ny));
    }
    for(const o of data.objects){if((o.type==='coin'||o.type==='chest')&&!collected[o.id]){
      if(Math.hypot(hero.x-(o.x+.5)*T,hero.y-(o.y+.5)*T)<23){collected[o.id]=true;coins+=o.type==='chest'?10:1;if(options.onHud)options.onHud(coins);if(options.onMessage)options.onMessage(o.type==='chest'?'เปิดหีบ +10 แต้ม':'เก็บเหรียญ +1');}
    }}
  }
  function updateEffects(dt){
    for(let i=effects.length-1;i>=0;i--){const p=effects[i];p.life-=dt;if(p.life<=0){effects.splice(i,1);continue;}p.vy+=p.gravity*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=Math.max(.0,1-dt*.45);}
    for(let i=rings.length-1;i>=0;i--){rings[i].time+=dt;if(rings[i].time>rings[i].life)rings.splice(i,1);}
  }
  function renderEffects(){
    for(const r of rings){let q=r.time/r.life;ctx.save();ctx.globalAlpha=(1-q)*.85;ctx.strokeStyle=r.color;
      ctx.lineWidth=3+(1-q)*7;ctx.beginPath();ctx.ellipse(r.x,r.y,8+q*100,5+q*57,0,0,Math.PI*2);ctx.stroke();ctx.restore();
      if(quality()!=='low')glow(r.x,r.y, Math.min(130,40+q*120),r.color,.16*(1-q));}
    ctx.save();ctx.globalCompositeOperation='lighter';
    for(const p of effects){const q=p.life/p.maxLife;ctx.globalAlpha=Math.min(1,q);ctx.fillStyle=p.color;
      let sz=Math.max(.8,p.size*q);ctx.fillRect(p.x-sz/2,p.y-sz/2,sz,sz);}
    ctx.restore();
  }
  function drawGrid(){ctx.save();ctx.strokeStyle='#e8f9f326';ctx.lineWidth=1;
    for(let x=0;x<=COLS;x++){ctx.beginPath();ctx.moveTo(x*T+.5,0);ctx.lineTo(x*T+.5,H);ctx.stroke();}
    for(let y=0;y<=ROWS;y++){ctx.beginPath();ctx.moveTo(0,y*T+.5);ctx.lineTo(W,y*T+.5);ctx.stroke();}ctx.restore();}
  function draw(dt){
    ctx.fillStyle='#29573e';ctx.fillRect(0,0,W,H);
    if(cacheDirty||!staticCache)rebuildStatic();else ctx.drawImage(staticCache,0,0);
    const ordered=[...data.objects].sort((a,b)=>a.y-b.y);
    let inserted=false; for(const ob of ordered){if(!inserted && (ob.y+.7)*T>hero.y){drawHero(hero.x,hero.y);inserted=true;}drawProp(ob);}
    if(!inserted)drawHero(hero.x,hero.y);
    if(quality()!=='low'){
      for(const o of data.objects){if(o.type==='torch')glow((o.x+.5)*T,(o.y-.12)*T,82,'#ffb65d',.34);}
    }
    renderEffects();
    if(mode==='edit' && options.grid)drawGrid();
    if(mode==='play'){
      roundRect(12,12,174,31,7,'#081f25c9');ctx.fillStyle='#f2e6ba';ctx.font='bold 16px sans-serif';ctx.fillText('✦  SCORE  '+coins,23,33);
    }
  }
  function frame(now){
    if(!playing)return;let dt=Math.min(.05,Math.max(0,(now-lastTime)/1000||.016));lastTime=now;t+=dt;
    accumulatedFPS+=dt;frameCounter++;if(accumulatedFPS>.65){fps=Math.round(frameCounter/accumulatedFPS);accumulatedFPS=0;frameCounter=0;if(options.onFPS)options.onFPS(fps);}
    if(mode==='play')movement(dt);updateEffects(dt);draw(dt);raf=requestAnimationFrame(frame);
  }
  function onKeyDown(e){if(mode!=='play'||['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
    if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key))e.preventDefault();keys[e.key]=true;
    if(e.key===' '||e.key.toLowerCase()==='j')cast(hero.x,hero.y);
    if(e.key.toLowerCase()==='e'){for(const o of data.objects){if(o.type==='npc'&&Math.hypot(hero.x-(o.x+.5)*T,hero.y-(o.y+.5)*T)<55&&options.onMessage)options.onMessage('ยินดีต้อนรับสู่โลกที่คุณสร้าง!');}}
  }
  function onKeyUp(e){keys[e.key]=false;}
  window.addEventListener('keydown',onKeyDown);window.addEventListener('keyup',onKeyUp);
  this.setProject=function(next){data=next;cacheDirty=true;};
  this.invalidate=function(){cacheDirty=true;};
  this.setMode=function(next){mode=next;if(next==='play'){hero={x:data.spawn.x*T+16,y:data.spawn.y*T+16};coins=0;enemies={};collected={};if(options.onHud)options.onHud(coins);}else {pad={x:0,y:0};}};
  this.setGrid=function(state){options.grid=state;};
  this.cast=function(x,y){return cast(x==null?hero.x:x,y==null?hero.y:y);};
  this.setPad=function(dx,dy){pad={x:dx,y:dy};};
  this.getPlayer=function(){return {...hero};};
  this.getFPS=function(){return fps;};
  this.start=function(){if(playing&&raf)return;playing=true;lastTime=performance.now();raf=requestAnimationFrame(frame);};
  this.destroy=function(){playing=false;cancelAnimationFrame(raf);window.removeEventListener('keydown',onKeyDown);window.removeEventListener('keyup',onKeyUp);};
  this.start();
}
window.TitanXGameRuntime = TitanXGameRuntime;
