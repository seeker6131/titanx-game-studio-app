(() => {
'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const WORLD_W = 28, WORLD_H = 16, PIX = 16;
const STORE = 'titanx-game-studio-project-v01';
const tileAssets=[['grass','🌿','หญ้า',0],['dirt','🟫','ดิน',1],['water','🌊','น้ำ',2],['stone','🪨','หิน',3],['sand','🏖️','ทราย',4],['wood','🪵','ไม้',5]];
const props=[['tree','🌳','ต้นไม้'],['house','🏠','บ้าน'],['rock','🪨','ก้อนหิน'],['bush','🌱','พุ่มไม้'],['torch','🔥','คบไฟ'],['npc','🧙','NPC'],['slime','🟢','สไลม์'],['coin','🪙','เหรียญ'],['chest','📦','หีบ']];
const presets={
 nova:{kind:'nova',color:'#71e6ff',count:60,speed:180,size:5,life:.8},
 flame:{kind:'flame',color:'#ff934e',count:65,speed:160,size:6,life:1.0},
 frost:{kind:'frost',color:'#b8eaff',count:65,speed:120,size:5,life:1.1},
 rain:{kind:'rain',color:'#d0b2ff',count:75,speed:260,size:3,life:.8},
 heal:{kind:'heal',color:'#7eff9c',count:45,speed:90,size:5,life:1.3}
};
const palette=['#212f44','#485771','#7d8b9c','#ffffff','#f1c999','#bf845f','#6a463a','#e55c6c','#ffb453','#ffdf73','#76ce9f','#357963','#4f92c5','#74d7e8','#ad80d5','#cc93c5','#000000',null];
let tab='world', tool='tiles', selectedTile=0, selectedProp='tree', pixelTool='pencil', pixelColor='#74d7e8', brushDown=false, lastCell='', dirtyStroke=false, undo=[], redo=[], saveTimer=0, toastTimer=0;
function heroTemplate(name){
  const a=Array(256).fill(null);let px=(x,y,c)=>{if(x>=0&&y>=0&&x<16&&y<16)a[y*16+x]=c;};
  const rect=(x,y,w,h,c)=>{for(let j=y;j<y+h;j++)for(let i=x;i<x+w;i++)px(i,j,c);};
  const outline='#283747',metal='#d8e2e9',shadow='#7994a8',skin='#f2c59c';
  // boots + legs
  rect(4,13,3,2,outline);rect(9,13,3,2,outline);rect(4,12,3,2,'#584d65');rect(9,12,3,2,'#584d65');
  if(name==='mage'){
    rect(3,7,10,6,'#2e568d');rect(5,6,6,8,'#695db1');rect(7,8,2,4,'#c9a3e6');
    rect(4,4,8,3,skin);rect(3,2,10,3,'#464270');rect(5,0,6,3,'#464270');rect(2,4,12,1,'#7866ad');
    rect(6,5,1,1,outline);rect(9,5,1,1,outline);
    rect(13,5,1,10,'#9c7444');rect(12,3,3,3,'#74d7e8');rect(13,2,1,1,'#e9f9ff');
  } else {
    rect(3,7,10,6,'#a24655');rect(4,6,8,8,outline);rect(5,7,6,6,metal);
    rect(6,8,4,4,shadow);rect(7,8,2,2,'#b7eafa');rect(2,8,3,3,metal);rect(11,8,3,3,metal);
    rect(4,2,8,6,outline);rect(5,3,6,4,skin);rect(4,2,8,2,shadow);rect(5,1,6,2,metal);
    rect(6,5,1,1,outline);rect(9,5,1,1,outline);
    rect(13,5,1,9,metal);rect(12,3,3,3,shadow);rect(13,2,1,1,metal);rect(12,13,3,2,'#e8c871');
  }
  return a;
}
function demoProject(){
 const tiles=Array.from({length:WORLD_H},(_,y)=>Array.from({length:WORLD_W},(_,x)=>{
   if(x>=18&&x<=27&&y>=11&&y<=15 && ((x-22)**2/35+(y-15)**2/24<1.8))return 2;
   if((x>=3&&x<=17&&y===9)||(x===9&&y>=3&&y<=12)||(x>=9&&x<22&&y===6))return 4;
   if(x>=11&&x<=17&&y>=1&&y<=4)return 1;
   if(x<3&&y<5&&((x+y)%3===0))return 3;
   return 0;
 }));
 const objects=[['tree',2,4],['tree',4,2],['tree',15,6],['tree',25,4],['tree',23,8],['tree',1,11],['tree',18,2],['house',13,3],['house',19,5],['rock',5,11],['bush',3,7],['bush',16,12],['torch',8,8],['torch',12,8],['npc',10,8],['coin',7,9],['coin',13,10],['chest',16,8],['slime',16,13],['slime',21,9]]
 .map(([type,x,y],i)=>({id:'demo-'+i,type,x,y}));
 return {version:1,name:'My Fantasy World',tiles,objects,spawn:{x:6,y:6},sprite:heroTemplate('knight'),fx:{...presets.nova},quality:'balanced'};
}
function validateProject(v){
 if(!v||typeof v!=='object'||!Array.isArray(v.tiles)||v.tiles.length!==WORLD_H || !v.tiles.every(row=>Array.isArray(row)&&row.length===WORLD_W))throw Error('ขนาดแผนที่ไม่ถูกต้อง');
 let p=demoProject();
 p.name=String(v.name||'My Game').slice(0,42);
 p.tiles=v.tiles.map(r=>r.map(i=>Number.isInteger(i)&&i>=0&&i<=5?i:0));
 p.objects=Array.isArray(v.objects)?v.objects.slice(0,350).filter(o=>o && props.some(it=>it[0]===o.type) &&Number.isInteger(o.x)&&Number.isInteger(o.y)&&o.x>=0&&o.x<WORLD_W&&o.y>=0&&o.y<WORLD_H).map((o,i)=>({type:o.type,x:o.x,y:o.y,id:String(o.id||'item-'+i).slice(0,80)})):[];
 p.spawn={x:Math.max(0,Math.min(WORLD_W-1,Number(v.spawn?.x)||6)),y:Math.max(0,Math.min(WORLD_H-1,Number(v.spawn?.y)||6))};
 p.sprite=Array.isArray(v.sprite)&&v.sprite.length===256?v.sprite.map(s=>(typeof s==='string'&&/^#[0-9a-fA-F]{6}$/.test(s))?s:null):heroTemplate('knight');
 let fx=v.fx||{};p.fx={kind:Object.hasOwn(presets,fx.kind)?fx.kind:'nova',color:/^#[0-9a-f]{6}$/i.test(fx.color)?fx.color:'#71e6ff',count:clamp(fx.count,5,150,60),speed:clamp(fx.speed,30,400,180),size:clamp(fx.size,1,13,5),life:clamp(fx.life,.2,2,.8)};
 p.quality=['low','balanced','high'].includes(v.quality)?v.quality:'balanced';
 return p;
}
function clamp(v,a,b,d){let n=Number(v);return Number.isFinite(n)?Math.min(b,Math.max(a,n)):d;}
let project;
try{const prior=localStorage.getItem(STORE);project=prior?validateProject(JSON.parse(prior)):demoProject();}catch(e){project=demoProject();}
let runtime = new TitanXGameRuntime($('#gameCanvas'),project,{mode:'edit',grid:true,onFPS:v=>{$('#fpsLabel').textContent=v+' FPS';},onHud:v=>{$('#scoreLabel').textContent=v;},onMessage:gameMessage});
function toast(msg){let el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600);}
let gameToastTimeout=0;
function gameMessage(msg){const el=$('#gameToast');el.textContent=msg;el.classList.remove('hidden');clearTimeout(gameToastTimeout);gameToastTimeout=setTimeout(()=>el.classList.add('hidden'),1700);}
function persist(){clearTimeout(saveTimer);$('#saveState').textContent='● กำลังบันทึก';saveTimer=setTimeout(()=>{try{localStorage.setItem(STORE,JSON.stringify(project));$('#saveState').textContent='● บันทึกแล้ว';}catch(e){$('#saveState').textContent='● บันทึกไม่ได้';toast('พื้นที่บันทึกไม่พร้อม กรุณาส่งออก JSON');}},400);}
function pushUndo(){undo.push(JSON.stringify(project));if(undo.length>40)undo.shift();redo=[];}
function refreshAll(){runtime.setProject(project);$('#projectName').value=project.name;$('#qualitySelect').value=project.quality;setFXForm();showTab(tab);persist();}
function historyMove(from,to){if(!from.length){toast('ยังไม่มีรายการให้ย้อนกลับ');return;}to.push(JSON.stringify(project));project=validateProject(JSON.parse(from.pop()));refreshAll();toast('เรียบร้อย');}
function showTab(next){tab=next;
 $$('.nav-tab').forEach(b=>b.classList.toggle('selected',b.dataset.tab===next));
 ['world','hero','fx','play'].forEach(n=>$('#'+n+'Inspector').classList.toggle('hidden',n!==next));
 $('#worldStage').classList.toggle('hidden',next==='hero');$('#spriteStage').classList.toggle('hidden',next!=='hero');$('#assetPanel').classList.toggle('hidden',next==='hero'||next==='play');
 $('#playControls').classList.toggle('hidden',next!=='play');$('#btnGrid').classList.toggle('hidden',next==='hero'||next==='play');
 $('#viewTitle').textContent={world:'SCENE EDITOR',hero:'CHARACTER CREATOR',fx:'VFX EDITOR',play:'LIVE PLAYTEST'}[next];
 $('#inspectorTitle').textContent={world:'World Settings',hero:'Character Tools',fx:'Particle Editor',play:'Game Test'}[next];
 $('#stageHint').textContent={world:'แตะหรือลากนิ้วบนแผนที่เพื่อสร้างฉาก',hero:'แตะหรือลากเพื่อวาดตัวละคร 16 × 16',fx:'ปรับค่าสกิล แล้วกดทดลองเอฟเฟกต์',play:'เดินเก็บเหรียญ ใช้ SKILL กำจัดสไลม์'}[next];
 runtime.setMode(next==='play'?'play':'edit');
 if(next==='world'||next==='fx')drawAssets();if(next==='hero'){drawSprite();drawPalette();}
 }
function drawAssets(){let root=$('#assetGrid');root.innerHTML='';if(tab==='fx'){
 $('#assetsTitle').textContent='EFFECT LIBRARY';$('#assetsInfo').textContent='เลือกต้นแบบเพื่อปรับแต่ง';
 const fxlist=[['nova','✦','Nova'],['flame','🔥','Flame'],['frost','❄','Frost'],['rain','☄','Rain'],['heal','✚','Heal']];
 for(const [id,icon,label] of fxlist){const b=document.createElement('button');b.className='asset-btn'+(project.fx.kind===id?' selected':'');b.innerHTML=`<span>${icon}</span>${label}`;b.onclick=()=>{pushUndo();project.fx={...presets[id]};setFXForm();runtime.setProject(project);drawAssets();runtime.cast(448,256);persist();};root.append(b);}return;
 }
 const items=tool==='props'?props:tool==='tiles'?tileAssets:[];
 $('#assetsTitle').textContent=tool==='props'?'OBJECT LIBRARY':'TILE PALETTE';
 $('#assetsInfo').textContent=tool==='spawn'?'แตะตำแหน่งเริ่มตัวละคร':tool==='erase'?'แตะวัตถุเพื่อลบ':'แตะเพื่อเลือกแปรง';
 for(const item of items){let id=item[0],b=document.createElement('button');b.className='asset-btn'+((tool==='props'?selectedProp===id:selectedTile===item[3])?' selected':'');
 const icon=document.createElement('span');icon.textContent=item[1];b.append(icon,document.createTextNode(item[2]));
 b.onclick=()=>{if(tool==='props')selectedProp=id;else selectedTile=item[3];updateSelection();drawAssets();};root.append(b);}
 updateSelection();
}
function updateSelection(){let item=tool==='props'?props.find(a=>a[0]===selectedProp):tool==='tiles'?tileAssets.find(a=>a[3]===selectedTile):null;
 $('#selectionIcon').textContent=item?item[1]:tool==='erase'?'⌫':'♟';
 $('#selectionName').textContent=item?item[2]:tool==='erase'?'ยางลบ':'ตำแหน่งเกิด';
 $('#selectionHint').textContent=tool==='props'?'เพิ่มวัตถุในฉาก':tool==='tiles'?'ใช้แปรงทาพื้น':tool==='erase'?'ลบวัตถุ หรือคืนพื้นหญ้า':'ตำแหน่งเริ่มเล่น';
 $$('.tool').forEach(b=>b.classList.toggle('selected',b.dataset.tool===tool));
}
function pointOnCanvas(e,canvas,cols,rows){let r=canvas.getBoundingClientRect(),xx=(e.clientX-r.left)/r.width,yy=(e.clientY-r.top)/r.height;
 return {x:Math.max(0,Math.min(cols-1,Math.floor(xx*cols))),y:Math.max(0,Math.min(rows-1,Math.floor(yy*rows)))};
}
function applyWorld(x,y){let key=`${x}:${y}`;if(lastCell===key)return;lastCell=key;
 if(tool==='tiles'){if(project.tiles[y][x]!==selectedTile){project.tiles[y][x]=selectedTile;dirtyStroke=true;runtime.invalidate();}}
 else if(tool==='props'){if(!project.objects.some(o=>o.x===x&&o.y===y&&o.type===selectedProp)){project.objects.push({id:'obj-'+Date.now()+'-'+Math.floor(Math.random()*999999),type:selectedProp,x,y});dirtyStroke=true;}}
 else if(tool==='erase'){let n=project.objects.length;project.objects=project.objects.filter(o=>o.x!==x||o.y!==y);if(n!==project.objects.length)dirtyStroke=true;else if(project.tiles[y][x]!==0){project.tiles[y][x]=0;dirtyStroke=true;runtime.invalidate();}}
 else if(tool==='spawn'){project.spawn={x,y};dirtyStroke=true;}
 $('#coordsLabel').textContent=`X ${x}  ·  Y ${y}`;
}
function startDraw(e,isHero){if(tab!==(isHero?'hero':'world'))return;if(e.button!==undefined && e.button!==0)return;
 e.preventDefault();brushDown=true;lastCell='';dirtyStroke=false;pushUndo();e.currentTarget.setPointerCapture(e.pointerId);drawAt(e,isHero);}
function drawAt(e,isHero){if(!brushDown)return;const pt=pointOnCanvas(e,e.currentTarget,isHero?PIX:WORLD_W,isHero?PIX:WORLD_H);
 if(isHero)applyPixel(pt.x,pt.y);else applyWorld(pt.x,pt.y);
}
function finishDraw(){if(!brushDown)return;brushDown=false;lastCell='';if(dirtyStroke){runtime.setProject(project);persist();}else undo.pop();}
const gameCanvas=$('#gameCanvas'),spriteCanvas=$('#spriteCanvas'),sctx=spriteCanvas.getContext('2d');
for(const [el,isHero] of [[gameCanvas,false],[spriteCanvas,true]]){
 el.addEventListener('pointerdown',e=>startDraw(e,isHero));el.addEventListener('pointermove',e=>drawAt(e,isHero));el.addEventListener('pointerup',finishDraw);el.addEventListener('pointercancel',finishDraw);
}
function drawSprite(){const cell=32;sctx.clearRect(0,0,512,512);
 for(let y=0;y<16;y++)for(let x=0;x<16;x++){sctx.fillStyle=(x+y)%2===0?'#2c4252':'#354e5f';sctx.fillRect(x*cell,y*cell,cell,cell);
 const color=project.sprite[y*16+x];if(color){sctx.fillStyle=color;sctx.fillRect(x*cell,y*cell,cell,cell);}}
 sctx.strokeStyle='#ffffff25';sctx.lineWidth=1;
 for(let i=0;i<=16;i++){sctx.beginPath();sctx.moveTo(i*cell+.5,0);sctx.lineTo(i*cell+.5,512);sctx.stroke();sctx.beginPath();sctx.moveTo(0,i*cell+.5);sctx.lineTo(512,i*cell+.5);sctx.stroke();}
}
function applyPixel(x,y){const id=y*16+x;if(lastCell===String(id))return;lastCell=String(id);
 let col=pixelTool==='eraser'?null:pixelColor;
 if(pixelTool==='fill'){
  const old=project.sprite[id];if(old===col)return;let stack=[id],seen=new Set();while(stack.length){let at=stack.pop();if(seen.has(at)||project.sprite[at]!==old)continue;seen.add(at);project.sprite[at]=col;
   let xx=at%16,yy=Math.floor(at/16);if(xx>0)stack.push(at-1);if(xx<15)stack.push(at+1);if(yy>0)stack.push(at-16);if(yy<15)stack.push(at+16);}dirtyStroke=true;
 } else if(project.sprite[id]!==col){project.sprite[id]=col;dirtyStroke=true;}
 drawSprite();
}
function drawPalette(){let root=$('#pixelPalette');root.innerHTML='';palette.forEach(color=>{const b=document.createElement('button');b.className='color-swatch'+(pixelColor===color?' selected':'');b.title=color||'Transparent';b.style.background=color||'repeating-conic-gradient(#fff 0 25%,#777 0 50%) 50% / 10px 10px';
 b.onclick=()=>{pixelTool=color?'pencil':'eraser';if(color)pixelColor=color;$$('.pixel-tool').forEach(a=>a.classList.toggle('selected',a.dataset.pixeltool===pixelTool));drawPalette();};root.append(b);});}
function setFXForm(){const v=project.fx;$('#fxPreset').value=v.kind;$('#fxColor').value=v.color;
 for(const [key,id,out] of [['count','fxCount','countOut'],['speed','fxSpeed','speedOut'],['size','fxSize','sizeOut'],['life','fxLife','lifeOut']]){$('#'+id).value=v[key];$('#'+out).textContent=v[key];}}
function loadBlob(name,type,content){const b=new Blob([content],{type}),url=URL.createObjectURL(b);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),12000);}
function fileSlug(v){return (v.trim().replace(/[^a-zA-Z0-9ก-๙_-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,48)||'my-game');}
function exportGame(){
 const name=project.name.replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
 const json=JSON.stringify(project).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');
 const script=`const data=${json};const game=new (${TitanXGameRuntime.toString()})(document.getElementById('g'),data,{mode:'play',onHud:s=>document.getElementById('score').textContent=s,onMessage:m=>{const t=document.getElementById('msg');t.textContent=m;setTimeout(()=>t.textContent='',1800)}});document.querySelectorAll('[data-m]').forEach(b=>{const [x,y]=b.dataset.m.split(',').map(Number);b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);game.setPad(x,y)};for(const ev of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(ev,()=>game.setPad(0,0))});document.getElementById('cast').onclick=()=>game.cast();`;
 const css=`*{box-sizing:border-box}body{margin:0;min-height:100dvh;background:#08131f;color:#f1f8f9;font:14px system-ui;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:13px;padding:14px}header{width:min(100%,1100px);display:flex;justify-content:space-between;align-items:center}header strong{font-size:19px}header small{color:#6eeabc}main{width:min(100%,1100px);aspect-ratio:7/4;position:relative;border:2px solid #377765;border-radius:9px;overflow:hidden}canvas{width:100%;height:100%;image-rendering:pixelated}#controls{position:absolute;inset:0;pointer-events:none;display:flex;justify-content:space-between;align-items:end;padding:10px}.pad{position:relative;width:124px;height:115px;pointer-events:auto}button{touch-action:none;background:#123947bf;border:1px solid #7aeac0;color:white;border-radius:9px;font-size:17px;width:39px;height:37px;position:absolute}.u{top:0;left:42px}.l{top:40px;left:0}.r{top:40px;right:0}.d{bottom:0;left:42px}#cast{position:static;pointer-events:auto;border-radius:50%;width:80px;height:80px;background:#325ba8db;color:#ffdb81;font-size:28px}#cast small{display:block;font-size:10px}#msg{position:absolute;top:11px;left:50%;transform:translateX(-50%);padding:6px;background:#0d2b33c9;color:#ffffc6;border-radius:6px}@media(max-width:600px){header strong{font-size:13px}.pad{transform:scale(.73);transform-origin:bottom left}#cast{transform:scale(.77);transform-origin:bottom right}}`;
 const html=`<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name} — TitanX</title><style>${css}</style></head><body><header><strong>✦ ${name}</strong><small>✦ คะแนน <span id="score">0</span></small></header><main><canvas id="g"></canvas><div id="msg"></div><div id="controls"><div class="pad"><button class="u" data-m="0,-1">▲</button><button class="l" data-m="-1,0">◀</button><button class="r" data-m="1,0">▶</button><button class="d" data-m="0,1">▼</button></div><button id="cast">✦<small>SKILL</small></button></div></main><footer>สร้างด้วย TitanX Game Studio • WASD / ลูกศร / Space</footer><script>${script}<\/script></body></html>`;
 loadBlob(fileSlug(project.name)+'-game.html','text/html;charset=utf-8',html);toast('ส่งออกเกม HTML แล้ว');$('#exportModal').classList.add('hidden');
}
function exportJSON(){loadBlob(fileSlug(project.name)+'.json','application/json',JSON.stringify(project,null,2));toast('ส่งออกโปรเจกต์ JSON แล้ว');$('#exportModal').classList.add('hidden');}
$$('.nav-tab').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
$$('.tool').forEach(b=>b.onclick=()=>{tool=b.dataset.tool;updateSelection();drawAssets();});
$$('.pixel-tool').forEach(b=>b.onclick=()=>{pixelTool=b.dataset.pixeltool;$$('.pixel-tool').forEach(x=>x.classList.toggle('selected',x===b));drawPalette();});
$('#projectName').onchange=e=>{pushUndo();project.name=(e.target.value.trim()||'My Fantasy World').slice(0,42);persist();};
$('#btnSave').onclick=()=>{persist();toast('บันทึกในเครื่องแล้ว (แนะนำให้สำรอง JSON ด้วย)');};
$('#qualitySelect').onchange=e=>{project.quality=e.target.value;persist();toast('ปรับคุณภาพ '+e.target.value);};
$('#btnGrid').onclick=e=>{let enabled=e.currentTarget.classList.toggle('active');runtime.setGrid(enabled);};
$('#btnUndo').onclick=()=>historyMove(undo,redo);$('#btnRedo').onclick=()=>historyMove(redo,undo);
$('#btnSample').onclick=()=>{if(!confirm('โหลดฉากตัวอย่างใหม่? งานปัจจุบันที่ยังไม่ส่งออกจะถูกแทนที่'))return;pushUndo();project=demoProject();refreshAll();toast('สร้างฉากตัวอย่างใหม่แล้ว');};
$('#btnKnight').onclick=()=>{pushUndo();project.sprite=heroTemplate('knight');runtime.setProject(project);drawSprite();persist();};
$('#btnMage').onclick=()=>{pushUndo();project.sprite=heroTemplate('mage');runtime.setProject(project);drawSprite();persist();};
$('#btnMirror').onclick=()=>{pushUndo();project.sprite=Array.from({length:256},(_,i)=>project.sprite[Math.floor(i/16)*16+15-(i%16)]);runtime.setProject(project);drawSprite();persist();};
$('#btnClearSprite').onclick=()=>{if(!confirm('ล้างภาพตัวละครทั้งหมด?'))return;pushUndo();project.sprite=Array(256).fill(null);runtime.setProject(project);drawSprite();persist();};
$('#pixelColorPicker').oninput=e=>{pixelColor=e.target.value;pixelTool='pencil';$$('.pixel-tool').forEach(x=>x.classList.toggle('selected',x.dataset.pixeltool==='pencil'));drawPalette();};
$('#fxPreset').onchange=e=>{pushUndo();project.fx={...presets[e.target.value]};setFXForm();runtime.setProject(project);drawAssets();persist();runtime.cast(448,256);};
$('#fxColor').oninput=e=>{project.fx.color=e.target.value;persist();};
for(const [key,id,out] of [['count','fxCount','countOut'],['speed','fxSpeed','speedOut'],['size','fxSize','sizeOut'],['life','fxLife','lifeOut']]){
 $('#'+id).oninput=e=>{project.fx[key]=Number(e.target.value);$('#'+out).textContent=e.target.value;persist();};
}
$('#btnPreviewFX').onclick=()=>{runtime.cast(448,255);toast('กำลังเล่นเอฟเฟกต์');};
$('#castButton').onclick=()=>runtime.cast();
$('#btnRestart').onclick=()=>{runtime.setMode('play');toast('เริ่มเล่นใหม่แล้ว');};
$$('.move-btn').forEach(b=>{let [dx,dy]=b.dataset.move.split(',').map(Number);b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);runtime.setPad(dx,dy);};
 for(const event of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(event,()=>runtime.setPad(0,0));});
$('#btnExport').onclick=()=>$('#exportModal').classList.remove('hidden');
$('#closeModal').onclick=()=>$('#exportModal').classList.add('hidden');
$('#exportModal').addEventListener('click',e=>{if(e.target.id==='exportModal')$('#exportModal').classList.add('hidden');});
$('#exportGame').onclick=exportGame;$('#exportJSON').onclick=exportJSON;
$('#importProject').onclick=()=>$('#importFile').click();
$('#importFile').onchange=async e=>{const file=e.target.files[0];if(!file)return;
 try{if(file.size>2_000_000)throw Error('ไฟล์ใหญ่เกินไป');const text=await file.text();const next=validateProject(JSON.parse(text));pushUndo();project=next;refreshAll();$('#exportModal').classList.add('hidden');toast('นำเข้าโปรเจกต์แล้ว');}catch(err){toast('นำเข้าไม่สำเร็จ: '+err.message);}e.target.value='';};
window.addEventListener('beforeunload',()=>{try{localStorage.setItem(STORE,JSON.stringify(project));}catch(e){}});
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
$('#projectName').value=project.name;$('#qualitySelect').value=project.quality;setFXForm();showTab('world');drawPalette();
window.TitanXStudioDebug={getProject:()=>project,setTab:showTab,exportGame,validateProject};
})();
