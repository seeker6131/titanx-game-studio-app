# TitanX Game Studio — Android Gradle Project v0.1.1

**นี่คือ SOURCE PROJECT สำหรับสร้าง APK จริงผ่าน Android SDK/Gradle ยังไม่ใช่ APK ที่คอมไพล์แล้ว และยังไม่มีการทดสอบบน Samsung S23 Ultra**

## ทำ APK ผ่าน GitHub Actions (มือถือ)
1. สร้าง GitHub Repository ใหม่ชื่อ `titanx-game-studio-app` แล้วนำไฟล์ทั้งหมดในโฟลเดอร์นี้ขึ้น repo (รวม `.github/workflows/build-apk.yml`)
2. ไปที่แท็บ Actions > Build TitanX APK > Run workflow (หรือให้ workflow เริ่มโดยอัตโนมัติหลัง push ไป `main`)
3. เมื่อผ่าน เข้า run ล่าสุด > Artifacts > `TitanX-Game-Studio-debug-apk` > Download
4. แตกไฟล์ ZIP ที่ได้ แล้วจะพบ `app-debug.apk` สำหรับติดตั้ง

APK ใช้ Android WebView โหลดไฟล์ Editor แบบ Offline จาก `assets/` ผ่าน file://, รองรับเลือกไฟล์ JSON ผ่านตัวเลือกไฟล์ Android และส่งออก HTML/JSON ผ่าน Android file save picker (WebView bridge)

สำคัญ: ไม่ได้อัปเดตเกม Quarter RPG และไม่จำเป็นต้องแก้สคริปต์ Termux ของเกมเดิม

## โครงสร้าง
- `app/src/main/assets/`: TitanX Game Studio HTML/CSS/JS
- `app/src/main/java/studio/titanx/app/MainActivity.java`: Android WebView + import/export bridge
- `app/src/main/AndroidManifest.xml`: package `studio.titanx.app`, Android API min 26, target 34
- `.github/workflows/build-apk.yml`: CI building `assembleDebug` using real Android SDK

## ข้อจำกัด
- ต้องมี GitHub Actions หรือเครื่องที่ติดตั้ง Gradle + Android SDK เพื่อคอมไพล์จริง
- APK แบบ Debug เหมาะสำหรับทดลอง ไม่ใช่ APK เซ็นเผยแพร่บน Play Store
- ยังไม่รับประกันคุณภาพ/ความลื่นหรือการติดตั้งก่อนทดสอบบนเครื่องจริง
